senvironment_fitness_with_segment_mahi.py soll vor dem Ausführen und Testen zum environment_fitness umbennant werden.
