

EPISODES = 1000
STEPS = 10
LR = 1e-6
CONV -> 1x16(5,2) -> 16x32(5,2) -> 32x32(5,2)
REDE -> INx512 -> RElu -> 512x512 -> RElu -> 512x512 -> RElu -> 512xOUT

REward = SOmente o ganho do mapa
