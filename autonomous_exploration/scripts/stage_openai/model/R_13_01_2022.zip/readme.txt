

EPISODES = 2000
STEPS = 5
LR = 1e-6
CONV -> 1x16(5,2) -> 16x32(5,2) -> 32x32(5,2)
REDE -> INx512 -> 512x512 -> 512x512 -> 512x512 -> 512x512 -> 512xOUT

REward = SOmente o ganho do mapa
